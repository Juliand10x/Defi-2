# Kibo · Aplicativo de Valoración y Gestión de Riesgo
**Universidad Externado de Colombia · Facultad de Finanzas, Gobierno y Relaciones Internacionales**

Kibo es una plataforma cuantitativa desarrollada en Python y Streamlit que automatiza la simulación estocástica de activos, valoración de opciones con árbol binomial, medición de VaR al 99% y optimización de portafolios de mínima varianza con límites sectoriales.

## 🚀 Cómo ejecutar en local

1. Instalar las dependencias oficiales:
   `ash
   pip install -r requirements.txt
   `

2. Iniciar la aplicación:
   `ash
   streamlit run app.py
   `

3. El navegador se abrirá automáticamente en http://localhost:8501.

## 📊 Módulos Principales
- **Paso 1 & 2**: Selección de capital y perfil de riesgo (presets del Externado).
- **Paso 3**: Selección de 10 acciones líderes de Wall Street y medidor de diversificación (6 sectores).
- **Paso 4**: Competencia estocástica bajo 5.000 trayectorias de Monte Carlo: GBM, Salto de Merton (MJD), Ornstein-Uhlenbeck (O-U) y Browniano Fraccionario (Hurst).
- **Paso 5**: Diagnóstico de Efecto Manada (Test CCK 2000).
- **Paso 6 a 9**: Opciones reales de Wall Street, Árbol Binomial CRR (Europea/Americana) con control de convergencia a USD .4506 y simulador de cobertura.
- **Paso 10**: Medición de riesgo con 3 estimadores de VaR al 99% (Paramétrico, Histórico y Monte Carlo) y 3 pruebas de estrés.
- **Paso 11 & 12**: Asignación óptima de portafolio mediante Programación Cuadrática SLSQP con límite del 35% por sector y ajuste a presupuesto de riesgo.
- **Paso 13**: Examen histórico rolling de 252 sesiones con RMSE/MAPE y auditoría fuera de muestra con Test de Kupiec.
